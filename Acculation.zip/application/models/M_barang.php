<?php
class M_barang extends CI_Model{

	function barang_list(){
		$hasil=$this->db->query("SELECT * FROM tbl_tamu Order by tanggal_input ASC");
		return $hasil->result();
	}

	function simpan_barang($vnamatamu,$vkomentartamu,$vjumlahtamu){
		$hasil=$this->db->query("INSERT INTO tbl_tamu (nama_tamu,komentar_tamu,jumlah_tamu,tanggal_input)VALUES('$vnamatamu','$vkomentartamu','$vjumlahtamu',now())");
		return $hasil;
	}

	function get_barang_by_kode($vnamatamu){
		$hsl=$this->db->query("SELECT * FROM tbl_tamu WHERE nama_tamu='$vnamatamu'");
		if($hsl->num_rows()>0){
			foreach ($hsl->result() as $data) {
				$hasil=array(
					'nama_tamu' => $data->nama_tamu,
					'komentar_tamu' => $data->komentar_tamu,
					'jumlah_tamu' => $data->jumlah_tamu,
					);
			}
		}
		return $hasil;
	}


	
}