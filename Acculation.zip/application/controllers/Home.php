<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_barang');
	}
	public function dashboard()
	{
        $this->load->view('particialdahboard/navbar');
		$this->load->view('home/dashboard');
		$this->load->view('particialdahboard/footer');
	}
	function data_barang(){
		$data=$this->m_barang->barang_list();
		echo json_encode($data);
	}
	function simpan_barang(){
		$vnamatamu=$this->input->post('vnamatamu');
		$vkomentartamu=$this->input->post('vkomentartamu');
		$vjumlahtamu=$this->input->post('vjumlahtamu');
		$data=$this->m_barang->simpan_barang($vnamatamu,$vkomentartamu,$vjumlahtamu);
		echo json_encode($data);
	}


}
