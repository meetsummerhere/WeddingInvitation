<!DOCTYPE html>
<html lang="id-ID">

<head>
  <meta charset = "UTF-8" />
	<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1.0">
	<title>𝓐𝓵𝓭𝓸 & 𝓐𝓷𝓰𝓮𝓵𝓲𝓷𝓪</title>
	<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery.min.js' id='jquery-core-js'></script>
	<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery-migrate.min.js' id='jquery-migrate-js'></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/db/js/jquery.dataTables.css'?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/db/js/bootstrap.css'?>">
</head>
<style>
@import url('https://fonts.googleapis.com/css2?family=Nunito:wght@800&display=swap');

html {

    box-sizing: border-box ;
    --duration: .45s ;
    --cubic: cubic-bezier(0.4, 0, 0.2, 1) ;
    --color-1: #d5dadd ;
    --color-2: #51d5c2 ;

}

html *,
html *::before,
html *::after {

    box-sizing: inherit ;

}
.bg {
    width: 100%;
    height: 700px;
    /* background-image: url('image.jpg'); */
    background-size: 100% 100%;
    border: 1px solid red;
}
body {
    opacity: 0;
            transition: opacity 3s;
/* 
    margin: 0 ;
   	height: 100vh ;
    display: flex ;
    overflow: hidden ;
    align-items: end ;
    justify-content: center ; 
    background-color: #f0f1f1 ;
    font-family: 'Nunito', sans-serif ; */
	background-image: url('<?php echo base_url(); ?>assets/img/bg.png');
    /* background-color: #f0f1f1 ; */
}
.paddingtext {
	padding: 16px;
}
.toggle {
	position: fixed;
  bottom: 0;
  /* right: 10px; */
  color: white;
  line-height: 30px;
  cursor: pointer;
  justify-content: center ; 
}
.btn-primary_rsv {
    color: #fff !important;
    background-color: #94765C !important;
    border-color: #fff !important;
}
#leftImage{
  left: 0;
  width: 150px;
  position: absolute;
}
.table.dataTable.table-striped.DTFC_Cloned tbody tr:nth-of-type(odd) {
  background: transparent !important;
}
.table.dataTable.table-striped.DTFC_Cloned tbody tr:nth-of-type(even) {
  background: transparent !important;
}

.table td, table tr, table th{
background: transparent !important;
}
#rightImage{
  right: 0;
  width: 150px;
  position: absolute;
}
#rightcenter{

  width: 150px;
  position: absolute;
}
.element-text {
    text-align: center;
}
.rounded-img {
  border-radius: 50%;
  width: 150px;
  margin-top:5%
}
.protokol-kesehatan-icon{
    width: 100px; 
}
.rounded-img-icon {
  border-radius: 50%;
  width: 45px;
  margin-top:5%
}
.rounded-img-snippet {
  width: 20px;
}

.btn-primary {
    color: #94765C !important;
    background-color: #fff !important;
    border-color: #fff !important;
}
.element-margin {
  margin-top:1%
}

#box {
  border: 1px solid;
  padding: 10px;
  box-shadow: 5px 10px #94765C;
  margin-top: 0%;
  border-radius : 1rem!important;
}
.text {
  color: #333;
}
.rounded-maps {
  border: 1px solid;
  padding: 10px;
  box-shadow: 5px 10px #e0d9d3;
  margin-top: 0%;
  border-radius : 1rem!important;
  background-color: #94765C;
}
.reveal.active{
  transform: translateY(0);
  opacity: 1;
}
.reveal{
  position: relative;
  transform: translateY(150px);
  opacity: 0;
  transition: 1s all ease;
}

@media (max-width: 900px){
  section h1{
    font-size: 2rem;
    text-align: center;
  }
  section .text-container{
    flex-direction: column;
  }
}
section{
  /* min-height: 100vh; */
  display: flex;
  justify-content: center;
  align-items: center;
}
section:nth-child(1){
  color: #e0ffff;
  }
section:nth-child(2){
  color: #42455a;
  /* background: #e0ffff; */
} 
section:nth-child(3){
  color: #e0ffff;
}
section:nth-child(4){
  color: #42455a;
  /* background: #e0ffff; */
}
/* section .container{
  margin: 100px;
} */
section h1{
  font-size: 3rem;
  margin: 20px;
}
section h2{
  font-size: 40px;
  text-align: center;
  text-transform: uppercase;
}
section .text-container{
   display: flex;
}
section .text-container .text-box{
  /* margin: 20px; */
  /* padding: 20px; */
  background: #00c2cb;
}
section .text-container .text-box h3{
  font-size: 30px;
  text-align: center;
  text-transform: uppercase;
  /* margin-bottom: 10px; */
}

.menu {

    margin: 0 ;
    width: 42em ;
    display: flex ;
    height: 10.4em ;
    user-select: none ;
    position: relative ;
    align-items: center ;
    padding: 0 1.9em 2.5em ;
    justify-content: center ;
    background-color: #fefefe ;
    border-radius: 1em 1em 4.5em 4.5em ;
    -webkit-tap-highlight-color: transparent ;

}

.container_down {
  color: #333;
  margin: 0 auto;
  text-align: center;
}

h1 {
  font-weight: normal;
  letter-spacing: .125rem;
  text-transform: uppercase;
}

li {
  display: inline-block;
  font-size: 1.5em;
  list-style-type: none;
  padding: 1em;
  text-transform: uppercase;
}

li span {
  display: block;
  font-size: 4.5rem;
}

.emoji {
  display: none;
  padding: 1rem;
}

.emoji span {
  font-size: 4rem;
  padding: 0 .5rem;
}

@media all and (max-width: 768px) {
  h1 {
    font-size: calc(1.5rem * var(--smaller));
  }
  
  li {
    font-size: calc(1.125rem * var(--smaller));
  }
  
  li span {
    font-size: calc(3.375rem * var(--smaller));
  }
}
@media (max-width: 42.625em) {
  
  .menu {
    
    font-size: .55em ;
    
  }
  
}

@media (min-width: 992px){
.element-protocol {
    flex: 0 0 auto;
    width: 23.333333%;
}
}
@media (min-width: 992px){
.element-gallery {
    flex: 0 0 auto;
    width: 23.333333%;
}
}

.gallery-foto {
    width: 192px;
}
.menu::after {

    height: 5% ;
    width: 35% ;
    bottom: 10% ;
    content: " " ;
    position: absolute ;
    border-radius: 1em ;
    background-color: #f2f3f4 ;


}

.menu__item {

    all: unset ;
    flex-grow: 1 ;
    display: flex ;
    cursor: pointer ;
    overflow: hidden ;
    padding-top: 0.5em ;
    position: relative ;
    align-items: center ;
    color: var(--color-1) ;
    justify-content: center ;
    transition: flex-grow var(--duration) var(--cubic) ;
    
}

.menu__icon {
    
    font-size: 1.05em ;
    stroke: currentColor ;
    transition: transform var(--duration) var(--cubic) ;
    
}

.menu__item::before {

    top: 9% ;
    left: 18.4% ;
    width: 1.5em ;
    height: 1.5em ;
    content: " ";
    position: absolute ;
    border-radius: 50% ;
    transform: scale(0) ;
    transform-origin: center ;
    background-color: #cca685 ;
    transition: transform var(--duration) var(--cubic) ;

}

.menu__item::after {

    left: 0;
    bottom: 0 ;
    content: " " ;
    height: 0.25em ;
    position: absolute ;
    border-radius: 2em ;
    transform-origin: left center ;
    background-color: currentColor ;
    width: calc( var(--lineWidth) + 5px ) ;
    transform: translate3d(3em , 0, 0) scaleX(0) ;
    transition: transform calc( var(--duration) + .2s) var(--cubic) ;

}


.menu__text {

    left: 4.15em ;
    font-size: 1.5em ;
    position: absolute ;
    text-transform: capitalize ;
    letter-spacing: .01em ;
    transform: translate3d(0, 109%, 0) ;
    transition: transform calc( var(--duration) / 3.7 ) ;

}

.menu__item.active {
    
    flex-grow: 2.7 ;
    color: #94765C ;
    
}

.menu__item.active .menu__icon {
    
    transform: translate3d(-95% , 0, 0) ;

    
}

.menu__item.active::before {

    transform: scale(1) ;

}

.menu__item.active::after {

    transform: translate3d(6.3em , 0, 0) scaleX(1) ;
    transition: transform var(--duration) var(--cubic) ;

}

.menu__text.active {

    transform: translate3d(0 , 0, 0) ;
    transition: transform calc(var(--duration) / 1.5) ;
}

.icon {

    --duration-icon: 1s ;
    
    fill: none ; 
    width: 2.5em ;
    height: 2.5em ;
    display: block ;
    stroke-width: 15 ;
    stroke-miterlimit: 10 ;
    
}


.active #home-anm {

    animation: home var(--duration-icon) ;
}

@keyframes home {

    25% {

        transform: translate3d(0, -.8em , 0) ;

    }

    50% {

        transform: translate3d(0, .5em , 0) ;

    }


}



#strategy-anm {
    
    transform: scaleX(.85) ;
    transform-origin: center ;

}

.active #strategy-anm {
    
    animation: strategy var(--duration-icon) ;

}

@keyframes strategy {
    
    50% {

        transform: scaleX(1) ;
        
    }
    
    100%{
        
        transform: scaleX(.85) ;

    }

}

.active #strategy-cir1 {

    animation: strategy-cir1 var(--duration-icon);
}

.active #strategy-cir2 {

    animation: strategy-cir2 var(--duration-icon) .1s;
}

.active #strategy-cir3 {

    animation: strategy-cir3 var(--duration-icon) .2s;
}

@keyframes strategy-cir1 {
    
    50% {

        transform: translate3d(-.7em,-0.7em,0);
        
    }
    
    100%{
        
        transform: translate3d(0,0,0);


    }

}

@keyframes strategy-cir2 {
    
    35% {

        transform: translate3d(0,-0.7em,0);
        
    }
    
    100%{
        
        transform: translate3d(0,0,0);


    }

}

@keyframes strategy-cir3 {
    
    35% {

        transform: translate3d(.7em,-0.7em,0);
        
    }
    
    100%{
        
        transform: translate3d(0,0,0);


    }

}


.active #period-anm {

    transform-origin: center 100% ;
    animation: period var(--duration-icon) ;

}

.active #period-cir {

    transform-origin: center ;
    animation: period-cir var(--duration-icon) ;

}

.active #period-line {

    stroke-dasharray: 66 ;
    animation: period-line calc( var(--duration-icon) / 2.5 ) reverse ;

}


@keyframes period {

    35% {

        transform: scaleY(.85) ;

    }

    60% , 70% {

        transform: scaleY(1.2) ;

    }

    100% {
        
        transform: scaleY(1) ;

    }

}

@keyframes period-cir {

    0%{

       opacity: 0 ;

    }

    35% {

        opacity: 1 ;
        transform: translate3d(15%, -55%, 0) ;

    }

    60%{

        opacity: 0 ;
        transform: translate3d(-8%, -50%, 0) ;

    }

}

@keyframes period-line {


    100% {

        stroke-dashoffset: 66 ;

    }

}


.active #security-cir {

    transform-box: fill-box ;
    transform-origin: center ;
    animation: security-cir calc( var(--duration-icon) / 1.5 ) ;

}

@keyframes security-cir {


    0% {

        transform: scale(0) ;
        
    }
    
    100% {
        
        transform: scale(1) ;
        
    }

}

.active #security-strok {

    stroke-dasharray: 96;
    animation: security-strok calc( var(--duration-icon) / 1.2 ) ;

}

@keyframes security-strok {


    0% {

        stroke-dashoffset: 60 ;
        
    }
    
    100% {
        
        stroke-dashoffset: 230 ;
        
    }

}

.active #settings-anm {

    transform-box: fill-box ;
    transform-origin: center ;
    animation: settings-anm calc( var(--duration-icon) / 1.5 ) ;

}

@keyframes settings-anm {


    0% {

        transform: rotate(-60deg);
        
    }
    
    50% {
        
        transform: rotate(60deg);
        
    }



    
}
</style>
<body onload="document.body.style.opacity='1'">
<!-- <body onload="document.body.style.opacity='1'" oncontextmenu="return false" > -->
