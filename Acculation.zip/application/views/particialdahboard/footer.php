<div class="toggle">
        <div class="row g-0">

            <div class="col-lg-4">
                <!-- <img class="w-100" src="https://placeimg.com/150/150/nature" alt="gambar alam"> -->
            </div>
            <div class="col-lg-4">
               
<menu class="menu">
        
        <button class="menu__item active">
            <div class="menu__icon" >

            <a href="#home"> <img class="icon" src='<?php echo base_url(); ?>assets/img/home.svg' viewBox="0 0 179.1 145">
                </img></a>

            </div>
            <strong  class="menu__text active">home</strong>
        </button>

        <button class="menu__item">
            <div class="menu__icon" >
            
               <a href="#date"> <img class="icon" src='<?php echo base_url(); ?>assets/img/calendar.svg' viewBox="0 0 179.1 145">
                </img></a>

            </div>
            <strong class="menu__text">Calendar</strong>
        </button>

        <button class="menu__item">
            <div class="menu__icon" >

            <a href="#maps"><img class="icon" src='<?php echo base_url(); ?>assets/img/maps.svg' viewBox="0 0 179.1 145">
                </img></a>

            </div>
            <strong class="menu__text">Maps</strong>
        </button>

        <button class="menu__item">
            <div class="menu__icon" >

            <a href="#gallery"><img class="icon" src='<?php echo base_url(); ?>assets/img/gallery.svg' viewBox="0 0 179.1 145">
                </img>
                </a>
            </div>
            <strong class="menu__text">Gallery</strong>
        </button>

        <button class="menu__item">
            <div class="menu__icon" >

          <a href = "#chat"> <img class="icon" src='<?php echo base_url(); ?>assets/img/chat.svg' viewBox="0 0 179.1 145">
                </img></a>

            </div>
            <strong class="menu__text">Chat</strong>
        </button>

    </menu>
            </div>
            <div class="col-lg-4">
                <!-- <img class="w-100" src="https://placeimg.com/150/150/nature" alt="gambar alam"> -->
            </div>
           
        </div>
    </div>

<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/wdp.min.js' id='weddingpress-wdp-js'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/dce-editor-copy.js' id='dce-clipboard-js-js'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/script.min.js' id='landingpress-js'></script>
<script>
// Designed by: Hoang Nguyen
// Original image: https://dribbble.com/shots/5919154-Tab-Bar-Label-Micro-Interaction

const buttons = document.querySelectorAll(".menu__item");
let activeButton = document.querySelector(".menu__item.active");

buttons.forEach(item => {

    const text = item.querySelector(".menu__text");
    setLineWidth(text, item);

    window.addEventListener("resize", () => {
        setLineWidth(text, item);
    })

    item.addEventListener("click", function() {
        if (this.classList.contains("active")) return;

        this.classList.add("active");
        
        if (activeButton) {
            activeButton.classList.remove("active");
            activeButton.querySelector(".menu__text").classList.remove("active");
        }
        
        handleTransition(this, text);
        activeButton = this;

    });

    
});


function setLineWidth(text, item) {
    const lineWidth = text.offsetWidth + "px";
    item.style.setProperty("--lineWidth", lineWidth);
}

function handleTransition(item, text) {

    item.addEventListener("transitionend", (e) => {

        if (e.propertyName != "flex-grow" || 
        !item.classList.contains("active")) return;

        text.classList.add("active");
        
    });

}
</script> 
<script>
    function reveal() {
  var reveals = document.querySelectorAll(".reveal");

  for (var i = 0; i < reveals.length; i++) {
    var windowHeight = window.innerHeight;
    var elementTop = reveals[i].getBoundingClientRect().top;
    var elementVisible = 150;

    if (elementTop < windowHeight - elementVisible) {
      reveals[i].classList.add("active");
    } else {
      reveals[i].classList.remove("active");
    }
  }
}

window.addEventListener("scroll", reveal);
</script>
<script>
(function () {
  const second = 1000,
        minute = second * 60,
        hour = minute * 60,
        day = hour * 24;

  let today = new Date(),
      dd = String(today.getDate()).padStart(2, "0"),
      mm = String(today.getMonth() + 1).padStart(2, "0"),
      yyyy = today.getFullYear(),
      nextYear = yyyy + 1,
      dayMonth = "06/28/",
      wedding = dayMonth + yyyy;
  
  today = mm + "/" + dd + "/" + yyyy;
  if (today > wedding) {
    wedding = dayMonth + nextYear;
  }
  //end
  
  const countDown = new Date(wedding).getTime(),
      x = setInterval(function() {    

        const now = new Date().getTime(),
              distance = countDown - now;

        document.getElementById("days").innerText = Math.floor(distance / (day)),
          document.getElementById("hours").innerText = Math.floor((distance % (day)) / (hour)),
          document.getElementById("minutes").innerText = Math.floor((distance % (hour)) / (minute)),
          document.getElementById("seconds").innerText = Math.floor((distance % (minute)) / second);

        //do something later when date is reached
        if (distance < 0) {
          document.getElementById("headline").innerText = "Today Is Our Wedding !";
          document.getElementById("countdown").style.display = "none";
          document.getElementById("content").style.display = "block";
          clearInterval(x);
        }
        //seconds
      }, 0)
  }());

</script>
<script type="text/javascript">
var myModal = document.getElementById('myModal')
var myInput = document.getElementById('myInput')

myModal.addEventListener('shown.bs.modal', function () {
  myInput.focus()
})
</script>
<script>
function myFunction() {
  var x = document.getElementById("myAudio").autoplay;
  document.getElementById("demo").innerHTML = x;
}

</script>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

<script type="text/javascript" src="<?php echo base_url().'assets/db/js/jquery.js'?>"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/db/js/bootstrap.js'?>"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/db/js/jquery.dataTables.js'?>"></script>
</body>
</html>
