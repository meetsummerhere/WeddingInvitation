<div id="cont">
		<div id="cont-logo">
      <!-- <a class="floating">السلام عليكم ورحمة الله وبركاته</a> -->
			<img src='<?php echo base_url(); ?>assets/img/icon.png' width="250" height="100" class="floating">
    </div>
    <br/>
    <div id="cont-textname">
      <a>WE INVITE YOU TO THE WEDDING OF</a>
      <p style="font-size: 35px;font-family: fantasy;text-shadow: 2px 3px 5px rgb(10 10 10 / 30%);">𝓐𝓵𝓭𝓸 & 𝓐𝓷𝓰𝓮𝓵𝓲𝓷𝓪</p>
			 <!-- <p><?php $uri_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
       $uri_segments = explode('/', $uri_path);
       echo $uri_segments[1]; ?></p> -->
		</div>
	  <div id="cont-boton">
		<a href="<?php echo site_url('Home/dashboard') ?>"> <button>Klik Disini !</button> </a>
		</div>
	
	  </div>
	  <div id="cont-footer">
			<p>Copyright © 2022 By Rosi ♥</p>
		</div>
	</div>