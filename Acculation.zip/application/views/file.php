<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>By Rosita</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="./style.css">

</head>
<style>
    /* ================
// Settings
// ============= */
/* ================
// Love Letters
// ============= */
.love {
  position: relative;
  margin-bottom: 6em;
  padding-top: 4em;
  text-align: center;
}
@media (min-width: 600px) {
  .love {
    left: 50%;
    margin-bottom: 0;
    margin-left: -9.375em;
    padding-top: 10em;
    transform: translate(-50%, 0);
  }
}

.letter {
  top: 0;
  left: 0;
  display: inline-block;
  font-size: 4vmin;
  text-shadow: 0 0 0.25em red, 0 0 0.35em red, 0 0 0.45em transparent, 0 0 0.55em transparent, 0 0 0.65em transparent;
}
@media (min-width: 600px) {
  .letter {
    offset-distance: 0;
    offset-path: path("m0, 0 c100, -150 200, -150 300, 0");
  }
}
.letter:nth-child(1) {
  -webkit-animation: twinkle 2.7s infinite 1.65s;
          animation: twinkle 2.7s infinite 1.65s;
  offset-distance: 5.5555555556%;
}
.letter:nth-child(2) {
  -webkit-animation: twinkle 2.7s infinite 0.6s;
          animation: twinkle 2.7s infinite 0.6s;
  offset-distance: 11.1111111111%;
}
.letter:nth-child(3) {
  -webkit-animation: twinkle 2.7s infinite 1.35s;
          animation: twinkle 2.7s infinite 1.35s;
  offset-distance: 16.6666666667%;
}
.letter:nth-child(4) {
  -webkit-animation: twinkle 2.7s infinite 2.7s;
          animation: twinkle 2.7s infinite 2.7s;
  offset-distance: 22.2222222222%;
}
.letter:nth-child(5) {
  -webkit-animation: twinkle 2.7s infinite 2.25s;
          animation: twinkle 2.7s infinite 2.25s;
  offset-distance: 27.7777777778%;
}
.letter:nth-child(6) {
  -webkit-animation: twinkle 2.7s infinite 2.4s;
          animation: twinkle 2.7s infinite 2.4s;
  offset-distance: 33.3333333333%;
}
.letter:nth-child(7) {
  -webkit-animation: twinkle 2.7s infinite 1.95s;
          animation: twinkle 2.7s infinite 1.95s;
  offset-distance: 38.8888888889%;
}
.letter:nth-child(8) {
  -webkit-animation: twinkle 2.7s infinite 2.4s;
          animation: twinkle 2.7s infinite 2.4s;
  offset-distance: 44.4444444444%;
}
.letter:nth-child(9) {
  -webkit-animation: twinkle 2.7s infinite 2.55s;
          animation: twinkle 2.7s infinite 2.55s;
  offset-distance: 50%;
}
.letter:nth-child(10) {
  -webkit-animation: twinkle 2.7s infinite 1.5s;
          animation: twinkle 2.7s infinite 1.5s;
  offset-distance: 55.5555555556%;
}
.letter:nth-child(11) {
  -webkit-animation: twinkle 2.7s infinite 0.6s;
          animation: twinkle 2.7s infinite 0.6s;
  offset-distance: 61.1111111111%;
}
.letter:nth-child(12) {
  -webkit-animation: twinkle 2.7s infinite 1.5s;
          animation: twinkle 2.7s infinite 1.5s;
  offset-distance: 66.6666666667%;
}
.letter:nth-child(13) {
  -webkit-animation: twinkle 2.7s infinite 0.3s;
          animation: twinkle 2.7s infinite 0.3s;
  offset-distance: 72.2222222222%;
}
.letter:nth-child(14) {
  -webkit-animation: twinkle 2.7s infinite 0.15s;
          animation: twinkle 2.7s infinite 0.15s;
  offset-distance: 77.7777777778%;
}
.letter:nth-child(15) {
  -webkit-animation: twinkle 2.7s infinite 0.75s;
          animation: twinkle 2.7s infinite 0.75s;
  offset-distance: 83.3333333333%;
}
.letter:nth-child(16) {
  -webkit-animation: twinkle 2.7s infinite 1.35s;
          animation: twinkle 2.7s infinite 1.35s;
  offset-distance: 88.8888888889%;
}
.letter:nth-child(17) {
  -webkit-animation: twinkle 2.7s infinite 1.95s;
          animation: twinkle 2.7s infinite 1.95s;
  offset-distance: 94.4444444444%;
}
.letter:nth-child(18) {
  -webkit-animation: twinkle 2.7s infinite 0.6s;
          animation: twinkle 2.7s infinite 0.6s;
  offset-distance: 100%;
}
.letter:empty {
  padding: 0 0.2em;
}

@-webkit-keyframes twinkle {
  50% {
    text-shadow: 0 0 0.25em red, 0 0 0.35em red, 0 0 0.45em red, 0 0 0.55em red, 0 0 0.65em red;
  }
}

@keyframes twinkle {
  50% {
    text-shadow: 0 0 0.25em red, 0 0 0.35em red, 0 0 0.45em red, 0 0 0.55em red, 0 0 0.65em red;
  }
}
/* ================
// Roses
// ============= */
.roses {
  position: relative;
  height: 50vmin;
  width: 100%;
  -webkit-animation: grow 10s forwards;
          animation: grow 10s forwards;
  transform: rotate(-180deg);
}

@-webkit-keyframes grow {
  100% {
    transform: rotate(15deg);
  }
}

@keyframes grow {
  100% {
    transform: rotate(15deg);
  }
}
.rose {
  position: absolute;
  top: 50%;
  left: 50%;
  perspective: 50em;
  transform: translate(-50%, -50%) rotate(-25deg);
  transform-style: preserve-3d;
}
.rose:nth-child(1) {
  z-index: 6;
  height: 6.15vmin;
  width: 6.15vmin;
}
.rose:nth-child(2) {
  z-index: 5;
  height: 9.75vmin;
  width: 9.75vmin;
}
.rose:nth-child(3) {
  z-index: 4;
  height: 15.2vmin;
  width: 15.2vmin;
}
.rose:nth-child(4) {
  z-index: 3;
  height: 20.7vmin;
  width: 20.7vmin;
}
.rose:nth-child(5) {
  z-index: 2;
  height: 20.05vmin;
  width: 20.05vmin;
}
.rose:nth-child(6) {
  z-index: 1;
  height: 25vmin;
  width: 25vmin;
}
.rose:nth-child(7) {
  z-index: 0;
  height: 30.15vmin;
  width: 30.15vmin;
}

.pedal {
  position: absolute;
  bottom: 50%;
  left: 50%;
  height: 100%;
  width: 100%;
  transform-origin: center 100%;
}
.pedal:before {
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
  content: "";
  border-radius: 0.35em 50% 35% 50%;
  transform: rotate(45deg);
}
.pedal:nth-child(1) {
  transform: translate(-50%, 0) rotateZ(51.4285714286deg) rotateX(-70deg) rotateY(8deg) scale(0);
}
.rose:nth-child(1) .pedal:nth-child(1) {
  -webkit-animation: flower-1 10s forwards 2.7s;
          animation: flower-1 10s forwards 2.7s;
}
.rose:nth-child(1) .pedal:nth-child(1):before {
  background: #ec0000;
}
.rose:nth-child(1) .pedal:nth-child(2) {
  -webkit-animation: flower-2 10s forwards 2.7s;
          animation: flower-2 10s forwards 2.7s;
}
.rose:nth-child(1) .pedal:nth-child(2):before {
  background: #dc0000;
}
.rose:nth-child(1) .pedal:nth-child(3) {
  -webkit-animation: flower-3 10s forwards 2.7s;
          animation: flower-3 10s forwards 2.7s;
}
.rose:nth-child(1) .pedal:nth-child(3):before {
  background: #d50000;
}
.rose:nth-child(1) .pedal:nth-child(4) {
  -webkit-animation: flower-4 10s forwards 2.7s;
          animation: flower-4 10s forwards 2.7s;
}
.rose:nth-child(1) .pedal:nth-child(4):before {
  background: #9a0000;
}
.rose:nth-child(1) .pedal:nth-child(5) {
  -webkit-animation: flower-5 10s forwards 2.7s;
          animation: flower-5 10s forwards 2.7s;
}
.rose:nth-child(1) .pedal:nth-child(5):before {
  background: #f60000;
}
.rose:nth-child(1) .pedal:nth-child(6) {
  -webkit-animation: flower-6 10s forwards 2.7s;
          animation: flower-6 10s forwards 2.7s;
}
.rose:nth-child(1) .pedal:nth-child(6):before {
  background: #de0000;
}
.rose:nth-child(1) .pedal:nth-child(7) {
  -webkit-animation: flower-7 10s forwards 2.7s;
          animation: flower-7 10s forwards 2.7s;
}
.rose:nth-child(1) .pedal:nth-child(7):before {
  background: #9a0000;
}
.pedal:nth-child(2) {
  transform: translate(-50%, 0) rotateZ(102.8571428571deg) rotateX(-70deg) rotateY(8deg) scale(0);
}
.rose:nth-child(2) .pedal:nth-child(1) {
  -webkit-animation: flower-1 10s forwards 2.25s;
          animation: flower-1 10s forwards 2.25s;
}
.rose:nth-child(2) .pedal:nth-child(1):before {
  background: #980000;
}
.rose:nth-child(2) .pedal:nth-child(2) {
  -webkit-animation: flower-2 10s forwards 2.25s;
          animation: flower-2 10s forwards 2.25s;
}
.rose:nth-child(2) .pedal:nth-child(2):before {
  background: #c30000;
}
.rose:nth-child(2) .pedal:nth-child(3) {
  -webkit-animation: flower-3 10s forwards 2.25s;
          animation: flower-3 10s forwards 2.25s;
}
.rose:nth-child(2) .pedal:nth-child(3):before {
  background: #bc0000;
}
.rose:nth-child(2) .pedal:nth-child(4) {
  -webkit-animation: flower-4 10s forwards 2.25s;
          animation: flower-4 10s forwards 2.25s;
}
.rose:nth-child(2) .pedal:nth-child(4):before {
  background: #ae0000;
}
.rose:nth-child(2) .pedal:nth-child(5) {
  -webkit-animation: flower-5 10s forwards 2.25s;
          animation: flower-5 10s forwards 2.25s;
}
.rose:nth-child(2) .pedal:nth-child(5):before {
  background: #e20000;
}
.rose:nth-child(2) .pedal:nth-child(6) {
  -webkit-animation: flower-6 10s forwards 2.25s;
          animation: flower-6 10s forwards 2.25s;
}
.rose:nth-child(2) .pedal:nth-child(6):before {
  background: #df0000;
}
.rose:nth-child(2) .pedal:nth-child(7) {
  -webkit-animation: flower-7 10s forwards 2.25s;
          animation: flower-7 10s forwards 2.25s;
}
.rose:nth-child(2) .pedal:nth-child(7):before {
  background: #f10000;
}
.pedal:nth-child(3) {
  transform: translate(-50%, 0) rotateZ(154.2857142857deg) rotateX(-70deg) rotateY(8deg) scale(0);
}
.rose:nth-child(3) .pedal:nth-child(1) {
  -webkit-animation: flower-1 10s forwards 1.8s;
          animation: flower-1 10s forwards 1.8s;
}
.rose:nth-child(3) .pedal:nth-child(1):before {
  background: #e50000;
}
.rose:nth-child(3) .pedal:nth-child(2) {
  -webkit-animation: flower-2 10s forwards 1.8s;
          animation: flower-2 10s forwards 1.8s;
}
.rose:nth-child(3) .pedal:nth-child(2):before {
  background: #a80000;
}
.rose:nth-child(3) .pedal:nth-child(3) {
  -webkit-animation: flower-3 10s forwards 1.8s;
          animation: flower-3 10s forwards 1.8s;
}
.rose:nth-child(3) .pedal:nth-child(3):before {
  background: #fe0000;
}
.rose:nth-child(3) .pedal:nth-child(4) {
  -webkit-animation: flower-4 10s forwards 1.8s;
          animation: flower-4 10s forwards 1.8s;
}
.rose:nth-child(3) .pedal:nth-child(4):before {
  background: #f00000;
}
.rose:nth-child(3) .pedal:nth-child(5) {
  -webkit-animation: flower-5 10s forwards 1.8s;
          animation: flower-5 10s forwards 1.8s;
}
.rose:nth-child(3) .pedal:nth-child(5):before {
  background: #a20000;
}
.rose:nth-child(3) .pedal:nth-child(6) {
  -webkit-animation: flower-6 10s forwards 1.8s;
          animation: flower-6 10s forwards 1.8s;
}
.rose:nth-child(3) .pedal:nth-child(6):before {
  background: #be0000;
}
.rose:nth-child(3) .pedal:nth-child(7) {
  -webkit-animation: flower-7 10s forwards 1.8s;
          animation: flower-7 10s forwards 1.8s;
}
.rose:nth-child(3) .pedal:nth-child(7):before {
  background: #e00000;
}
.pedal:nth-child(4) {
  transform: translate(-50%, 0) rotateZ(205.7142857143deg) rotateX(-70deg) rotateY(8deg) scale(0);
}
.rose:nth-child(4) .pedal:nth-child(1) {
  -webkit-animation: flower-1 10s forwards 1.35s;
          animation: flower-1 10s forwards 1.35s;
}
.rose:nth-child(4) .pedal:nth-child(1):before {
  background: #ba0000;
}
.rose:nth-child(4) .pedal:nth-child(2) {
  -webkit-animation: flower-2 10s forwards 1.35s;
          animation: flower-2 10s forwards 1.35s;
}
.rose:nth-child(4) .pedal:nth-child(2):before {
  background: #c80000;
}
.rose:nth-child(4) .pedal:nth-child(3) {
  -webkit-animation: flower-3 10s forwards 1.35s;
          animation: flower-3 10s forwards 1.35s;
}
.rose:nth-child(4) .pedal:nth-child(3):before {
  background: #a40000;
}
.rose:nth-child(4) .pedal:nth-child(4) {
  -webkit-animation: flower-4 10s forwards 1.35s;
          animation: flower-4 10s forwards 1.35s;
}
.rose:nth-child(4) .pedal:nth-child(4):before {
  background: #c90000;
}
.rose:nth-child(4) .pedal:nth-child(5) {
  -webkit-animation: flower-5 10s forwards 1.35s;
          animation: flower-5 10s forwards 1.35s;
}
.rose:nth-child(4) .pedal:nth-child(5):before {
  background: #f30000;
}
.rose:nth-child(4) .pedal:nth-child(6) {
  -webkit-animation: flower-6 10s forwards 1.35s;
          animation: flower-6 10s forwards 1.35s;
}
.rose:nth-child(4) .pedal:nth-child(6):before {
  background: #f50000;
}
.rose:nth-child(4) .pedal:nth-child(7) {
  -webkit-animation: flower-7 10s forwards 1.35s;
          animation: flower-7 10s forwards 1.35s;
}
.rose:nth-child(4) .pedal:nth-child(7):before {
  background: #a00000;
}
.pedal:nth-child(5) {
  transform: translate(-50%, 0) rotateZ(257.1428571429deg) rotateX(-70deg) rotateY(8deg) scale(0);
}
.rose:nth-child(5) .pedal:nth-child(1) {
  -webkit-animation: flower-1 10s forwards 0.9s;
          animation: flower-1 10s forwards 0.9s;
}
.rose:nth-child(5) .pedal:nth-child(1):before {
  background: #990000;
}
.rose:nth-child(5) .pedal:nth-child(2) {
  -webkit-animation: flower-2 10s forwards 0.9s;
          animation: flower-2 10s forwards 0.9s;
}
.rose:nth-child(5) .pedal:nth-child(2):before {
  background: #c30000;
}
.rose:nth-child(5) .pedal:nth-child(3) {
  -webkit-animation: flower-3 10s forwards 0.9s;
          animation: flower-3 10s forwards 0.9s;
}
.rose:nth-child(5) .pedal:nth-child(3):before {
  background: #d90000;
}
.rose:nth-child(5) .pedal:nth-child(4) {
  -webkit-animation: flower-4 10s forwards 0.9s;
          animation: flower-4 10s forwards 0.9s;
}
.rose:nth-child(5) .pedal:nth-child(4):before {
  background: #f00000;
}
.rose:nth-child(5) .pedal:nth-child(5) {
  -webkit-animation: flower-5 10s forwards 0.9s;
          animation: flower-5 10s forwards 0.9s;
}
.rose:nth-child(5) .pedal:nth-child(5):before {
  background: #f70000;
}
.rose:nth-child(5) .pedal:nth-child(6) {
  -webkit-animation: flower-6 10s forwards 0.9s;
          animation: flower-6 10s forwards 0.9s;
}
.rose:nth-child(5) .pedal:nth-child(6):before {
  background: #a30000;
}
.rose:nth-child(5) .pedal:nth-child(7) {
  -webkit-animation: flower-7 10s forwards 0.9s;
          animation: flower-7 10s forwards 0.9s;
}
.rose:nth-child(5) .pedal:nth-child(7):before {
  background: #9b0000;
}
.pedal:nth-child(6) {
  transform: translate(-50%, 0) rotateZ(308.5714285714deg) rotateX(-70deg) rotateY(8deg) scale(0);
}
.rose:nth-child(6) .pedal:nth-child(1) {
  -webkit-animation: flower-1 10s forwards 0.45s;
          animation: flower-1 10s forwards 0.45s;
}
.rose:nth-child(6) .pedal:nth-child(1):before {
  background: #bd0000;
}
.rose:nth-child(6) .pedal:nth-child(2) {
  -webkit-animation: flower-2 10s forwards 0.45s;
          animation: flower-2 10s forwards 0.45s;
}
.rose:nth-child(6) .pedal:nth-child(2):before {
  background: #f50000;
}
.rose:nth-child(6) .pedal:nth-child(3) {
  -webkit-animation: flower-3 10s forwards 0.45s;
          animation: flower-3 10s forwards 0.45s;
}
.rose:nth-child(6) .pedal:nth-child(3):before {
  background: #d80000;
}
.rose:nth-child(6) .pedal:nth-child(4) {
  -webkit-animation: flower-4 10s forwards 0.45s;
          animation: flower-4 10s forwards 0.45s;
}
.rose:nth-child(6) .pedal:nth-child(4):before {
  background: #b40000;
}
.rose:nth-child(6) .pedal:nth-child(5) {
  -webkit-animation: flower-5 10s forwards 0.45s;
          animation: flower-5 10s forwards 0.45s;
}
.rose:nth-child(6) .pedal:nth-child(5):before {
  background: #9b0000;
}
.rose:nth-child(6) .pedal:nth-child(6) {
  -webkit-animation: flower-6 10s forwards 0.45s;
          animation: flower-6 10s forwards 0.45s;
}
.rose:nth-child(6) .pedal:nth-child(6):before {
  background: #f70000;
}
.rose:nth-child(6) .pedal:nth-child(7) {
  -webkit-animation: flower-7 10s forwards 0.45s;
          animation: flower-7 10s forwards 0.45s;
}
.rose:nth-child(6) .pedal:nth-child(7):before {
  background: #ca0000;
}
.pedal:nth-child(7) {
  transform: translate(-50%, 0) rotateZ(360deg) rotateX(-70deg) rotateY(8deg) scale(0);
}
.rose:nth-child(7) .pedal:nth-child(1) {
  -webkit-animation: flower-1 10s forwards 0s;
          animation: flower-1 10s forwards 0s;
}
.rose:nth-child(7) .pedal:nth-child(1):before {
  background: #ef0000;
}
.rose:nth-child(7) .pedal:nth-child(2) {
  -webkit-animation: flower-2 10s forwards 0s;
          animation: flower-2 10s forwards 0s;
}
.rose:nth-child(7) .pedal:nth-child(2):before {
  background: #b60000;
}
.rose:nth-child(7) .pedal:nth-child(3) {
  -webkit-animation: flower-3 10s forwards 0s;
          animation: flower-3 10s forwards 0s;
}
.rose:nth-child(7) .pedal:nth-child(3):before {
  background: #e00000;
}
.rose:nth-child(7) .pedal:nth-child(4) {
  -webkit-animation: flower-4 10s forwards 0s;
          animation: flower-4 10s forwards 0s;
}
.rose:nth-child(7) .pedal:nth-child(4):before {
  background: #f70000;
}
.rose:nth-child(7) .pedal:nth-child(5) {
  -webkit-animation: flower-5 10s forwards 0s;
          animation: flower-5 10s forwards 0s;
}
.rose:nth-child(7) .pedal:nth-child(5):before {
  background: #e70000;
}
.rose:nth-child(7) .pedal:nth-child(6) {
  -webkit-animation: flower-6 10s forwards 0s;
          animation: flower-6 10s forwards 0s;
}
.rose:nth-child(7) .pedal:nth-child(6):before {
  background: #b00000;
}
.rose:nth-child(7) .pedal:nth-child(7) {
  -webkit-animation: flower-7 10s forwards 0s;
          animation: flower-7 10s forwards 0s;
}
.rose:nth-child(7) .pedal:nth-child(7):before {
  background: #f80000;
}

@-webkit-keyframes flower-1 {
  100% {
    transform: translate(-50%, 0) rotateZ(51.4285714286deg) rotateX(0) rotateY(8deg) scale(1);
  }
}

@keyframes flower-1 {
  100% {
    transform: translate(-50%, 0) rotateZ(51.4285714286deg) rotateX(0) rotateY(8deg) scale(1);
  }
}
@-webkit-keyframes flower-2 {
  100% {
    transform: translate(-50%, 0) rotateZ(102.8571428571deg) rotateX(0) rotateY(8deg) scale(1);
  }
}
@keyframes flower-2 {
  100% {
    transform: translate(-50%, 0) rotateZ(102.8571428571deg) rotateX(0) rotateY(8deg) scale(1);
  }
}
@-webkit-keyframes flower-3 {
  100% {
    transform: translate(-50%, 0) rotateZ(154.2857142857deg) rotateX(0) rotateY(8deg) scale(1);
  }
}
@keyframes flower-3 {
  100% {
    transform: translate(-50%, 0) rotateZ(154.2857142857deg) rotateX(0) rotateY(8deg) scale(1);
  }
}
@-webkit-keyframes flower-4 {
  100% {
    transform: translate(-50%, 0) rotateZ(205.7142857143deg) rotateX(0) rotateY(8deg) scale(1);
  }
}
@keyframes flower-4 {
  100% {
    transform: translate(-50%, 0) rotateZ(205.7142857143deg) rotateX(0) rotateY(8deg) scale(1);
  }
}
@-webkit-keyframes flower-5 {
  100% {
    transform: translate(-50%, 0) rotateZ(257.1428571429deg) rotateX(0) rotateY(8deg) scale(1);
  }
}
@keyframes flower-5 {
  100% {
    transform: translate(-50%, 0) rotateZ(257.1428571429deg) rotateX(0) rotateY(8deg) scale(1);
  }
}
@-webkit-keyframes flower-6 {
  100% {
    transform: translate(-50%, 0) rotateZ(308.5714285714deg) rotateX(0) rotateY(8deg) scale(1);
  }
}
@keyframes flower-6 {
  100% {
    transform: translate(-50%, 0) rotateZ(308.5714285714deg) rotateX(0) rotateY(8deg) scale(1);
  }
}
@-webkit-keyframes flower-7 {
  100% {
    transform: translate(-50%, 0) rotateZ(360deg) rotateX(0) rotateY(8deg) scale(1);
  }
}
@keyframes flower-7 {
  100% {
    transform: translate(-50%, 0) rotateZ(360deg) rotateX(0) rotateY(8deg) scale(1);
  }
}
/* ================
// Bursts
// ============= */
.bubbles {
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
  pointer-events: none;
}

.bubble {
  position: absolute;
  z-index: 200;
  border-radius: 50%;
}
.bubble:nth-child(1) {
  top: 58%;
  left: 90%;
  height: 14vmin;
  width: 14vmin;
  -webkit-animation: love-burst 3s infinite 0s;
          animation: love-burst 3s infinite 0s;
  box-shadow: inset 0 0 0 7vmin #fff;
  transform: translate(0, 0.6em) scale(0);
  transform-origin: center bottom;
}
.bubble:nth-child(2) {
  top: 49%;
  left: 27%;
  height: 14vmin;
  width: 14vmin;
  -webkit-animation: love-burst 3s infinite 0.15s;
          animation: love-burst 3s infinite 0.15s;
  box-shadow: inset 0 0 0 7vmin #fff;
  transform: translate(0, 0.05em) scale(0);
  transform-origin: center bottom;
}
.bubble:nth-child(3) {
  top: 4%;
  left: 96%;
  height: 4vmin;
  width: 4vmin;
  -webkit-animation: love-burst 3s infinite 0.3s;
          animation: love-burst 3s infinite 0.3s;
  box-shadow: inset 0 0 0 2vmin #fff;
  transform: translate(0, 0.4em) scale(0);
  transform-origin: center bottom;
}
.bubble:nth-child(4) {
  top: 9%;
  left: 74%;
  height: 9vmin;
  width: 9vmin;
  -webkit-animation: love-burst 3s infinite 0.45s;
          animation: love-burst 3s infinite 0.45s;
  box-shadow: inset 0 0 0 4.5vmin #fff;
  transform: translate(0, 0.6em) scale(0);
  transform-origin: center bottom;
}
.bubble:nth-child(5) {
  top: 40%;
  left: 91%;
  height: 10vmin;
  width: 10vmin;
  -webkit-animation: love-burst 3s infinite 0.6s;
          animation: love-burst 3s infinite 0.6s;
  box-shadow: inset 0 0 0 5vmin #fff;
  transform: translate(0, 0.85em) scale(0);
  transform-origin: center bottom;
}
.bubble:nth-child(6) {
  top: 72%;
  left: 73%;
  height: 15vmin;
  width: 15vmin;
  -webkit-animation: love-burst 3s infinite 0.75s;
          animation: love-burst 3s infinite 0.75s;
  box-shadow: inset 0 0 0 7.5vmin #fff;
  transform: translate(0, 0.5em) scale(0);
  transform-origin: center bottom;
}
.bubble:nth-child(7) {
  top: 54%;
  left: 40%;
  height: 15vmin;
  width: 15vmin;
  -webkit-animation: love-burst 3s infinite 0.9s;
          animation: love-burst 3s infinite 0.9s;
  box-shadow: inset 0 0 0 7.5vmin #fff;
  transform: translate(0, 0.05em) scale(0);
  transform-origin: center bottom;
}
.bubble:nth-child(8) {
  top: 51%;
  left: 89%;
  height: 12vmin;
  width: 12vmin;
  -webkit-animation: love-burst 3s infinite 1.05s;
          animation: love-burst 3s infinite 1.05s;
  box-shadow: inset 0 0 0 6vmin #fff;
  transform: translate(0, 1.05em) scale(0);
  transform-origin: center bottom;
}
.bubble:nth-child(9) {
  top: 86%;
  left: 94%;
  height: 7vmin;
  width: 7vmin;
  -webkit-animation: love-burst 3s infinite 1.2s;
          animation: love-burst 3s infinite 1.2s;
  box-shadow: inset 0 0 0 3.5vmin #fff;
  transform: translate(0, 0.05em) scale(0);
  transform-origin: center bottom;
}
.bubble:nth-child(10) {
  top: 69%;
  left: 73%;
  height: 20vmin;
  width: 20vmin;
  -webkit-animation: love-burst 3s infinite 1.35s;
          animation: love-burst 3s infinite 1.35s;
  box-shadow: inset 0 0 0 10vmin #fff;
  transform: translate(0, 0.7em) scale(0);
  transform-origin: center bottom;
}
.bubble:nth-child(11) {
  top: 11%;
  left: 78%;
  height: 20vmin;
  width: 20vmin;
  -webkit-animation: love-burst 3s infinite 1.5s;
          animation: love-burst 3s infinite 1.5s;
  box-shadow: inset 0 0 0 10vmin #fff;
  transform: translate(0, 0.8em) scale(0);
  transform-origin: center bottom;
}
.bubble:nth-child(12) {
  top: 96%;
  left: 47%;
  height: 6vmin;
  width: 6vmin;
  -webkit-animation: love-burst 3s infinite 1.65s;
          animation: love-burst 3s infinite 1.65s;
  box-shadow: inset 0 0 0 3vmin #fff;
  transform: translate(0, 0.7em) scale(0);
  transform-origin: center bottom;
}
.bubble:nth-child(13) {
  top: 2%;
  left: 94%;
  height: 7vmin;
  width: 7vmin;
  -webkit-animation: love-burst 3s infinite 1.8s;
          animation: love-burst 3s infinite 1.8s;
  box-shadow: inset 0 0 0 3.5vmin #fff;
  transform: translate(0, 0.9em) scale(0);
  transform-origin: center bottom;
}
.bubble:nth-child(14) {
  top: 22%;
  left: 61%;
  height: 18vmin;
  width: 18vmin;
  -webkit-animation: love-burst 3s infinite 1.95s;
          animation: love-burst 3s infinite 1.95s;
  box-shadow: inset 0 0 0 9vmin #fff;
  transform: translate(0, 0.9em) scale(0);
  transform-origin: center bottom;
}
.bubble:nth-child(15) {
  top: 58%;
  left: 41%;
  height: 14vmin;
  width: 14vmin;
  -webkit-animation: love-burst 3s infinite 2.1s;
          animation: love-burst 3s infinite 2.1s;
  box-shadow: inset 0 0 0 7vmin #fff;
  transform: translate(0, 1.15em) scale(0);
  transform-origin: center bottom;
}
.bubble:nth-child(16) {
  top: 73%;
  left: 76%;
  height: 20vmin;
  width: 20vmin;
  -webkit-animation: love-burst 3s infinite 2.25s;
          animation: love-burst 3s infinite 2.25s;
  box-shadow: inset 0 0 0 10vmin #fff;
  transform: translate(0, 0.25em) scale(0);
  transform-origin: center bottom;
}
.bubble:nth-child(17) {
  top: 90%;
  left: 12%;
  height: 14vmin;
  width: 14vmin;
  -webkit-animation: love-burst 3s infinite 2.4s;
          animation: love-burst 3s infinite 2.4s;
  box-shadow: inset 0 0 0 7vmin #fff;
  transform: translate(0, 0.7em) scale(0);
  transform-origin: center bottom;
}
.bubble:nth-child(18) {
  top: 22%;
  left: 10%;
  height: 2vmin;
  width: 2vmin;
  -webkit-animation: love-burst 3s infinite 2.55s;
          animation: love-burst 3s infinite 2.55s;
  box-shadow: inset 0 0 0 1vmin #fff;
  transform: translate(0, 0.95em) scale(0);
  transform-origin: center bottom;
}
.bubble:nth-child(19) {
  top: 29%;
  left: 17%;
  height: 16vmin;
  width: 16vmin;
  -webkit-animation: love-burst 3s infinite 2.7s;
          animation: love-burst 3s infinite 2.7s;
  box-shadow: inset 0 0 0 8vmin #fff;
  transform: translate(0, 0.5em) scale(0);
  transform-origin: center bottom;
}
.bubble:nth-child(20) {
  top: 68%;
  left: 66%;
  height: 4vmin;
  width: 4vmin;
  -webkit-animation: love-burst 3s infinite 2.85s;
          animation: love-burst 3s infinite 2.85s;
  box-shadow: inset 0 0 0 2vmin #fff;
  transform: translate(0, 0.2em) scale(0);
  transform-origin: center bottom;
}

@-webkit-keyframes love-burst {
  50%, 100% {
    box-shadow: inset 0 0 0 0 red;
    transform: translate(0, 0) scale(1);
  }
}

@keyframes love-burst {
  50%, 100% {
    box-shadow: inset 0 0 0 0 red;
    transform: translate(0, 0) scale(1);
  }
}
.heart {
  fill: #fff;
  opacity: 0;
}
.bubble:nth-child(1) .heart {
  -webkit-animation: love 3s forwards infinite 0s;
          animation: love 3s forwards infinite 0s;
  transform: scale(0.5) rotate(-5deg);
}
.bubble:nth-child(2) .heart {
  -webkit-animation: love 3s forwards infinite 0.15s;
          animation: love 3s forwards infinite 0.15s;
  transform: scale(0.5) rotate(13deg);
}
.bubble:nth-child(3) .heart {
  -webkit-animation: love 3s forwards infinite 0.3s;
          animation: love 3s forwards infinite 0.3s;
  transform: scale(0.5) rotate(-33deg);
}
.bubble:nth-child(4) .heart {
  -webkit-animation: love 3s forwards infinite 0.45s;
          animation: love 3s forwards infinite 0.45s;
  transform: scale(0.5) rotate(49deg);
}
.bubble:nth-child(5) .heart {
  -webkit-animation: love 3s forwards infinite 0.6s;
          animation: love 3s forwards infinite 0.6s;
  transform: scale(0.5) rotate(-24deg);
}
.bubble:nth-child(6) .heart {
  -webkit-animation: love 3s forwards infinite 0.75s;
          animation: love 3s forwards infinite 0.75s;
  transform: scale(0.5) rotate(15deg);
}
.bubble:nth-child(7) .heart {
  -webkit-animation: love 3s forwards infinite 0.9s;
          animation: love 3s forwards infinite 0.9s;
  transform: scale(0.5) rotate(-35deg);
}
.bubble:nth-child(8) .heart {
  -webkit-animation: love 3s forwards infinite 1.05s;
          animation: love 3s forwards infinite 1.05s;
  transform: scale(0.5) rotate(32deg);
}
.bubble:nth-child(9) .heart {
  -webkit-animation: love 3s forwards infinite 1.2s;
          animation: love 3s forwards infinite 1.2s;
  transform: scale(0.5) rotate(-22deg);
}
.bubble:nth-child(10) .heart {
  -webkit-animation: love 3s forwards infinite 1.35s;
          animation: love 3s forwards infinite 1.35s;
  transform: scale(0.5) rotate(8deg);
}
.bubble:nth-child(11) .heart {
  -webkit-animation: love 3s forwards infinite 1.5s;
          animation: love 3s forwards infinite 1.5s;
  transform: scale(0.5) rotate(-28deg);
}
.bubble:nth-child(12) .heart {
  -webkit-animation: love 3s forwards infinite 1.65s;
          animation: love 3s forwards infinite 1.65s;
  transform: scale(0.5) rotate(12deg);
}
.bubble:nth-child(13) .heart {
  -webkit-animation: love 3s forwards infinite 1.8s;
          animation: love 3s forwards infinite 1.8s;
  transform: scale(0.5) rotate(-32deg);
}
.bubble:nth-child(14) .heart {
  -webkit-animation: love 3s forwards infinite 1.95s;
          animation: love 3s forwards infinite 1.95s;
  transform: scale(0.5) rotate(4deg);
}
.bubble:nth-child(15) .heart {
  -webkit-animation: love 3s forwards infinite 2.1s;
          animation: love 3s forwards infinite 2.1s;
  transform: scale(0.5) rotate(-22deg);
}
.bubble:nth-child(16) .heart {
  -webkit-animation: love 3s forwards infinite 2.25s;
          animation: love 3s forwards infinite 2.25s;
  transform: scale(0.5) rotate(20deg);
}
.bubble:nth-child(17) .heart {
  -webkit-animation: love 3s forwards infinite 2.4s;
          animation: love 3s forwards infinite 2.4s;
  transform: scale(0.5) rotate(-22deg);
}
.bubble:nth-child(18) .heart {
  -webkit-animation: love 3s forwards infinite 2.55s;
          animation: love 3s forwards infinite 2.55s;
  transform: scale(0.5) rotate(4deg);
}
.bubble:nth-child(19) .heart {
  -webkit-animation: love 3s forwards infinite 2.7s;
          animation: love 3s forwards infinite 2.7s;
  transform: scale(0.5) rotate(-28deg);
}
.bubble:nth-child(20) .heart {
  -webkit-animation: love 3s forwards infinite 2.85s;
          animation: love 3s forwards infinite 2.85s;
  transform: scale(0.5) rotate(16deg);
}

@-webkit-keyframes love {
  50% {
    fill: red;
    opacity: 1;
  }
}

@keyframes love {
  50% {
    fill: red;
    opacity: 1;
  }
}
/* ================
// Structure
// ============= */
html,
body {
  height: 100%;
}

html {
  overflow: hidden;
  font-family: "Petit Formal Script";
  background: radial-gradient(ellipse at center, #051838, #0A093B 100%);
  color: #fff;
}
    </style>
<body>
<!-- partial:index.partial.html -->
<link href="https://fonts.googleapis.com/css?family=Petit+Formal+Script" rel="stylesheet">
<div class="love"><span class="letter">I</span><span class="letter"></span><span class="letter">L</span><span class="letter">o</span><span class="letter">v</span><span class="letter">e</span><span class="letter"></span><span class="letter">Y</span><span class="letter">o</span><span class="letter">u</span><span class="letter"></span><span class="letter">O</span><span class="letter">n</span><span class="letter">g</span><span class="letter">k</span><span class="letter">o</span><span class="letter">!</span>
</div>
<div class="roses">
  <div class="rose">
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
  </div>
  <div class="rose">
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
  </div>
  <div class="rose">
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
  </div>
  <div class="rose">
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
  </div>
  <div class="rose">
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
  </div>
  <div class="rose">
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
  </div>
  <div class="rose">
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
    <div class="pedal"></div>
  </div>
</div>
<div class="bubbles">
  <div class="bubble"><svg class="heart" viewBox="0 0 32 32">
<title>heart22</title>
<path d="M23.6 2c-3.363 0-6.258 2.736-7.599 5.594-1.342-2.858-4.237-5.594-7.601-5.594-4.637 0-8.4 3.764-8.4 8.401 0 9.433 9.516 11.906 16.001 21.232 6.13-9.268 15.999-12.1 15.999-21.232 0-4.637-3.763-8.401-8.4-8.401z"></path>
</svg>
  </div>
  <div class="bubble"><svg class="heart" viewBox="0 0 32 32">
<title>heart22</title>
<path d="M23.6 2c-3.363 0-6.258 2.736-7.599 5.594-1.342-2.858-4.237-5.594-7.601-5.594-4.637 0-8.4 3.764-8.4 8.401 0 9.433 9.516 11.906 16.001 21.232 6.13-9.268 15.999-12.1 15.999-21.232 0-4.637-3.763-8.401-8.4-8.401z"></path>
</svg>
  </div>
  <div class="bubble"><svg class="heart" viewBox="0 0 32 32">
<title>heart22</title>
<path d="M23.6 2c-3.363 0-6.258 2.736-7.599 5.594-1.342-2.858-4.237-5.594-7.601-5.594-4.637 0-8.4 3.764-8.4 8.401 0 9.433 9.516 11.906 16.001 21.232 6.13-9.268 15.999-12.1 15.999-21.232 0-4.637-3.763-8.401-8.4-8.401z"></path>
</svg>
  </div>
  <div class="bubble"><svg class="heart" viewBox="0 0 32 32">
<title>heart22</title>
<path d="M23.6 2c-3.363 0-6.258 2.736-7.599 5.594-1.342-2.858-4.237-5.594-7.601-5.594-4.637 0-8.4 3.764-8.4 8.401 0 9.433 9.516 11.906 16.001 21.232 6.13-9.268 15.999-12.1 15.999-21.232 0-4.637-3.763-8.401-8.4-8.401z"></path>
</svg>
  </div>
  <div class="bubble"><svg class="heart" viewBox="0 0 32 32">
<title>heart22</title>
<path d="M23.6 2c-3.363 0-6.258 2.736-7.599 5.594-1.342-2.858-4.237-5.594-7.601-5.594-4.637 0-8.4 3.764-8.4 8.401 0 9.433 9.516 11.906 16.001 21.232 6.13-9.268 15.999-12.1 15.999-21.232 0-4.637-3.763-8.401-8.4-8.401z"></path>
</svg>
  </div>
  <div class="bubble"><svg class="heart" viewBox="0 0 32 32">
<title>heart22</title>
<path d="M23.6 2c-3.363 0-6.258 2.736-7.599 5.594-1.342-2.858-4.237-5.594-7.601-5.594-4.637 0-8.4 3.764-8.4 8.401 0 9.433 9.516 11.906 16.001 21.232 6.13-9.268 15.999-12.1 15.999-21.232 0-4.637-3.763-8.401-8.4-8.401z"></path>
</svg>
  </div>
  <div class="bubble"><svg class="heart" viewBox="0 0 32 32">
<title>heart22</title>
<path d="M23.6 2c-3.363 0-6.258 2.736-7.599 5.594-1.342-2.858-4.237-5.594-7.601-5.594-4.637 0-8.4 3.764-8.4 8.401 0 9.433 9.516 11.906 16.001 21.232 6.13-9.268 15.999-12.1 15.999-21.232 0-4.637-3.763-8.401-8.4-8.401z"></path>
</svg>
  </div>
  <div class="bubble"><svg class="heart" viewBox="0 0 32 32">
<title>heart22</title>
<path d="M23.6 2c-3.363 0-6.258 2.736-7.599 5.594-1.342-2.858-4.237-5.594-7.601-5.594-4.637 0-8.4 3.764-8.4 8.401 0 9.433 9.516 11.906 16.001 21.232 6.13-9.268 15.999-12.1 15.999-21.232 0-4.637-3.763-8.401-8.4-8.401z"></path>
</svg>
  </div>
  <div class="bubble"><svg class="heart" viewBox="0 0 32 32">
<title>heart22</title>
<path d="M23.6 2c-3.363 0-6.258 2.736-7.599 5.594-1.342-2.858-4.237-5.594-7.601-5.594-4.637 0-8.4 3.764-8.4 8.401 0 9.433 9.516 11.906 16.001 21.232 6.13-9.268 15.999-12.1 15.999-21.232 0-4.637-3.763-8.401-8.4-8.401z"></path>
</svg>
  </div>
  <div class="bubble"><svg class="heart" viewBox="0 0 32 32">
<title>heart22</title>
<path d="M23.6 2c-3.363 0-6.258 2.736-7.599 5.594-1.342-2.858-4.237-5.594-7.601-5.594-4.637 0-8.4 3.764-8.4 8.401 0 9.433 9.516 11.906 16.001 21.232 6.13-9.268 15.999-12.1 15.999-21.232 0-4.637-3.763-8.401-8.4-8.401z"></path>
</svg>
  </div>
  <div class="bubble"><svg class="heart" viewBox="0 0 32 32">
<title>heart22</title>
<path d="M23.6 2c-3.363 0-6.258 2.736-7.599 5.594-1.342-2.858-4.237-5.594-7.601-5.594-4.637 0-8.4 3.764-8.4 8.401 0 9.433 9.516 11.906 16.001 21.232 6.13-9.268 15.999-12.1 15.999-21.232 0-4.637-3.763-8.401-8.4-8.401z"></path>
</svg>
  </div>
  <div class="bubble"><svg class="heart" viewBox="0 0 32 32">
<title>heart22</title>
<path d="M23.6 2c-3.363 0-6.258 2.736-7.599 5.594-1.342-2.858-4.237-5.594-7.601-5.594-4.637 0-8.4 3.764-8.4 8.401 0 9.433 9.516 11.906 16.001 21.232 6.13-9.268 15.999-12.1 15.999-21.232 0-4.637-3.763-8.401-8.4-8.401z"></path>
</svg>
  </div>
  <div class="bubble"><svg class="heart" viewBox="0 0 32 32">
<title>heart22</title>
<path d="M23.6 2c-3.363 0-6.258 2.736-7.599 5.594-1.342-2.858-4.237-5.594-7.601-5.594-4.637 0-8.4 3.764-8.4 8.401 0 9.433 9.516 11.906 16.001 21.232 6.13-9.268 15.999-12.1 15.999-21.232 0-4.637-3.763-8.401-8.4-8.401z"></path>
</svg>
  </div>
  <div class="bubble"><svg class="heart" viewBox="0 0 32 32">
<title>heart22</title>
<path d="M23.6 2c-3.363 0-6.258 2.736-7.599 5.594-1.342-2.858-4.237-5.594-7.601-5.594-4.637 0-8.4 3.764-8.4 8.401 0 9.433 9.516 11.906 16.001 21.232 6.13-9.268 15.999-12.1 15.999-21.232 0-4.637-3.763-8.401-8.4-8.401z"></path>
</svg>
  </div>
  <div class="bubble"><svg class="heart" viewBox="0 0 32 32">
<title>heart22</title>
<path d="M23.6 2c-3.363 0-6.258 2.736-7.599 5.594-1.342-2.858-4.237-5.594-7.601-5.594-4.637 0-8.4 3.764-8.4 8.401 0 9.433 9.516 11.906 16.001 21.232 6.13-9.268 15.999-12.1 15.999-21.232 0-4.637-3.763-8.401-8.4-8.401z"></path>
</svg>
  </div>
  <div class="bubble"><svg class="heart" viewBox="0 0 32 32">
<title>heart22</title>
<path d="M23.6 2c-3.363 0-6.258 2.736-7.599 5.594-1.342-2.858-4.237-5.594-7.601-5.594-4.637 0-8.4 3.764-8.4 8.401 0 9.433 9.516 11.906 16.001 21.232 6.13-9.268 15.999-12.1 15.999-21.232 0-4.637-3.763-8.401-8.4-8.401z"></path>
</svg>
  </div>
  <div class="bubble"><svg class="heart" viewBox="0 0 32 32">
<title>heart22</title>
<path d="M23.6 2c-3.363 0-6.258 2.736-7.599 5.594-1.342-2.858-4.237-5.594-7.601-5.594-4.637 0-8.4 3.764-8.4 8.401 0 9.433 9.516 11.906 16.001 21.232 6.13-9.268 15.999-12.1 15.999-21.232 0-4.637-3.763-8.401-8.4-8.401z"></path>
</svg>
  </div>
  <div class="bubble"><svg class="heart" viewBox="0 0 32 32">
<title>heart22</title>
<path d="M23.6 2c-3.363 0-6.258 2.736-7.599 5.594-1.342-2.858-4.237-5.594-7.601-5.594-4.637 0-8.4 3.764-8.4 8.401 0 9.433 9.516 11.906 16.001 21.232 6.13-9.268 15.999-12.1 15.999-21.232 0-4.637-3.763-8.401-8.4-8.401z"></path>
</svg>
  </div>
  <div class="bubble"><svg class="heart" viewBox="0 0 32 32">
<title>heart22</title>
<path d="M23.6 2c-3.363 0-6.258 2.736-7.599 5.594-1.342-2.858-4.237-5.594-7.601-5.594-4.637 0-8.4 3.764-8.4 8.401 0 9.433 9.516 11.906 16.001 21.232 6.13-9.268 15.999-12.1 15.999-21.232 0-4.637-3.763-8.401-8.4-8.401z"></path>
</svg>
  </div>
  <div class="bubble"><svg class="heart" viewBox="0 0 32 32">
<title>heart22</title>
<path d="M23.6 2c-3.363 0-6.258 2.736-7.599 5.594-1.342-2.858-4.237-5.594-7.601-5.594-4.637 0-8.4 3.764-8.4 8.401 0 9.433 9.516 11.906 16.001 21.232 6.13-9.268 15.999-12.1 15.999-21.232 0-4.637-3.763-8.401-8.4-8.401z"></path>
</svg>
  </div>
</div>
<!-- partial -->
  
</body>
</html>
