<!-- <audio autoplay >
    <source src="<?php echo base_url(); ?>assets/music/theme.mp3" type="audio/mpeg">
  </audio> -->
  <audio id="myAudio" controls autoplay loop>
  <source src="<?php echo base_url(); ?>assets/music/theme.mp3" type="audio/ogg">
  <source src="<?php echo base_url(); ?>assets/music/theme.mp3" type="audio/mpeg">
</audio>
<!-- ICON LEFT AND RIGHT START -->
<div class="row">
  <div class="col-6">
    <img src="
			
			<?php echo base_url(); ?>assets/img/1.png" id="leftImage" />
  </div>
  <div class="col-6">
    <img src="
				
				<?php echo base_url(); ?>assets/img/2.png" id="rightImage" />
  </div>
</div>
<!-- ICON LEFT AND RIGHT END -->
<!-- CONTENT START -->
<div class="container paddingtext">
  <div class="row" id="home">
    <div class="col-lg-12 col-12 element-text">
      <img src="
						
						<?php echo base_url(); ?>assets/img/icon1.png" class="rounded-img-icon" />
    </div>
    <div class="col-lg-12 col-12 element-text">
      <a>
        <b>السلام عليكم ورحمة الله وبركاته</b>
      </a>
    </div>
    <br />
    <br />
    <div class="col-lg-12 col-12 element-text" style="
    margin-bottom: 5%;
    margin-top: 5%;
">
      <a>َمِنْ آيَاتِهِ أَنْ خَلَقَ لَكُمْ مِنْ أَنْفُسِكُمْ أَزْوَاجًا لِتَسْكُنُوا إِلَيْهَا وَجَعَلَ بَيْنَكُمْ مَوَدَّةً وَرَحْمَةً ۚ إِنَّ فِي ذَٰلِكَ لَآيَاتٍ لِقَوْمٍ يَتَفَكَّرُونَ</a>
    </div>
    <br />
    <br />
    <div class="col-lg-12 col-12 element-text">
      <a>“Dan di antara tanda-tanda kekuasaan-Nya ialah Dia menciptakan untukmu istri-istri dari jenismu sendiri, supaya kamu cenderung dan merasa tentram kepadanya, dan dijadikan-Nya di antaramu rasa kasih dan sayang. Sesungguhnya pada yang demikian itu benar-benar terdapat tanda-tanda bagi kaum yang berpikir.” <br>
        <br>
        <b>- QS. Ar-Rum : 21 -</b>
      </a>
    </div>
    <div class="col-lg-12 col-12 element-text">
      <img src="
									
									<?php echo base_url(); ?>assets/img/pria.jpg" class="rounded-img" />
    </div>
    <div class="col-lg-12 col-12 element-text element-margin">
      <a>𝓐𝓵𝓭𝓸</a>
    </div>
    <div class="col-lg-12 col-12 element-text element-margin">
      <a>Putra dari Bapak H.Haris Simuli & Ibu Assiah Astuti </a>
    </div>
    <div class="col-lg-12 col-12 element-text">
      <img src="
										
										<?php echo base_url(); ?>assets/img/wanita.jpg" class="rounded-img" />
    </div>
    <div class="col-lg-12 col-12 element-text element-margin">
      <a>𝓐𝓷𝓰𝓮𝓵𝓲𝓷𝓪</a>
    </div>
    <div class="col-lg-12 col-12 element-text element-margin">
      <a>Putra dari Bapak Santo Baskoro & Ibu Sri Rahayu </a>
    </div>
    <!--EVENT-->
    <section>
      <div class="container reveal" id="date">
        <div class="col-lg-12 col-12 element-text">
          <img src="
						
													<?php echo base_url(); ?>assets/img/icon1.png" class="rounded-img-icon" />
        </div>
        <div class="col-lg-12 col-12 element-text">
          <a>Our Wedding Event</a>
        </div>
        <div class="col-lg-12 col-12 element-text element-margin">
          <div id="box" class="rounded">
            <div class="row">
              <a>Merupakan suatu kehormatan dan kebahagiaan bagi kami atas kehadiran Bapak/Ibu/Saudara/i untuk memberikan doa restu kepada putra-putri kami. </a>
            </div>
            <div class="row">
              <div class="col-lg-12 col-12 element-text element-margin">
                <img src="
									
																	<?php echo base_url(); ?>assets/img/calendar.svg" class="rounded-img-snippet" />
              </div>
              <div class="col-lg-12 col-12 element-text element-margin">
                <a>AKAD NIKAH</a>
              </div>
              <div class="col-lg-12 col-12 element-text element-margin">
                <a>Senin, 28 Juni 2022</a>
              </div>
              <div class="col-lg-12 col-12 element-text element-margin">
                <a>10:00 WIB - Selesai </a>
              </div>
              <div class="col-lg-12 col-12 element-text element-margin">
                <a>Masjid Jami Al-Hikmah </a>
              </div>
              <div class="col-lg-12 col-12 element-text element-margin">
                <a>Kota Tangerang </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--SAVE DATE-->
    <section>
      <div class="container reveal" id="date">
        <div class="col-lg-12 col-12 element-text element-margin">
          <div class="row">
            <div class="col-lg-12 col-12 element-text element-margin">
              <img src="
									
																	<?php echo base_url(); ?>assets/img/Save-The-Date-Brown.gif" style="width: 200px;" />
            </div>
            <!-- partial:index.partial.html -->
            <div class="container_down">
              <h4 id="headline"></h4>
              <div id="countdown">
                <ul>
                  <li>
                    <span id="days"></span>days
                  </li>
                  <li>
                    <span id="hours"></span>Hours
                  </li>
                  <li>
                    <span id="minutes"></span>Minutes
                  </li>
                  <li>
                    <span id="seconds"></span>Seconds
                  </li>
                </ul>
              </div>
              <div id="content" class="emoji">
                <span>♥</span>
                <span>♥</span>
                <span>♥</span>
              </div>
            </div>
            <!-- partial -->
          </div>
        </div>
      </div>
    </section>
    <!--MAPS-->
    <section>
      <div class="container reveal" id="maps">
        <div class="col-lg-12 col-12 element-text">
          <img src="
													
																<?php echo base_url(); ?>assets/img/icon1.png" class="rounded-img-icon" />
        </div>
        <div class="col-lg-12 col-12 element-text">
          <a>Our Wedding Location</a>
        </div>
        <div class="col-lg-12 col-12 element-text element-margin">
          <div class="rounded-maps">
            <div class="col-lg-12 col-12 element-text element-margin">
              <a style="color: white;">
                <b>Google Maps</b>
              </a>
            </div>
            <div class="col-lg-12 col-12 element-text element-margin">
              <a href="https://www.google.com/maps/place/Hutan+Kota+Srengseng/@-6.2193664,106.8171264,12z/data=!4m8!1m2!10m1!1e1!3m4!1s0x2e69f72f3706b613:0x11aab933dc9527ac!8m2!3d-6.2106945!4d106.7643954">
                <button type="button" class="btn btn-primary btn-sm">Get Direction</button>
              </a>
            </div>
            <br />
            <div class="col-sm-12 col-md-12 col-lg-12 col-12 element-text element-margin">
              <iframe data-v-e7448742="" width="100%" height="300" frameborder="0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyBPJP52KENyMYbfmFSNQAm9BXvVO7fSveA&amp;q=6P3QP595%2B5P&amp;center=-8.282013299999997,115.1593265&amp;zoom=16" allowfullscreen="allowfullscreen" style="border: 0px; border-radius: 20px;"></iframe>
            </div>
          </div>
        </div>
      </div>
  </div>
  </section>

  
  <!-- PROTOCOL -->
  <section>
    <div class="container reveal">
      <div class="col-lg-12 col-12 element-text">
        <img src="
						
																<?php echo base_url(); ?>assets/img/icon1.png" class="rounded-img-icon" />
      </div>
      <div class="col-lg-12 col-12 element-text">
        <a>Our Wedding Protocol</a>
      </div>
      <div class="col-lg-12 col-12 element-text element-margin">
        <div id="box" class="rounded">
          <div class="row">
            <a>
              <b>Protokol Kesehatan</b>
            </a>
          </div>
          <div class="col-lg-12 col-12 element-text element-margin">
            <a> Demi mendukung kesehatan Bersama alangkah baiknya para tamu yang akan hadir memenuhi protokol kesehatan sebagai berikut: </a>
          </div>
          <div class="row">
            <div class="element-protocol">
              <img src="	
																				<?php echo base_url(); ?>assets/img/handsanitizer.png" class="protokol-kesehatan-icon" />
              <div class="col-lg-12 col-12 element-text">
                <a>Wash Your Hand</a>
              </div>
            </div>
            <div class="element-protocol">
              <img src="	
																					<?php echo base_url(); ?>assets/img/mask.png" class="protokol-kesehatan-icon" />
              <div class="col-lg-12 col-12 element-text">
                <a>Wear a Mask</a>
              </div>
            </div>
            <div class="element-protocol">
              <img src="	
																						<?php echo base_url(); ?>assets/img/nohandshake.png" class="protokol-kesehatan-icon" />
              <div class="col-lg-12 col-12 element-text">
                <a>Avoid physical contact</a>
              </div>
            </div>
            <div class="element-protocol">
              <img src="	
																							<?php echo base_url(); ?>assets/img/socialdistancing.png" class="protokol-kesehatan-icon" />
              <div class="col-lg-12 col-12 element-text">
                <a>Social Distancing</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</section>

  <!-- GALLERY -->
  <section>
    <div class="container reveal" id="gallery">
      <div class="col-lg-12 col-12 element-text">
        <img src="
						
																<?php echo base_url(); ?>assets/img/icon1.png" class="rounded-img-icon" />
      </div>
      <div class="col-lg-12 col-12 element-text">
        <p class="text">Our Wedding Protocol</p>
      </div>
      <div class="col-lg-12 col-12 element-text element-margin">
        <div id="box" class="rounded">
        
          <div class="row">
            <div class="element-gallery">
              <img src="	
																				<?php echo base_url(); ?>assets/img/gallery/1.JFIF" class="gallery-foto" />
              
            </div>
            <div class="element-gallery">
              <img src="	
																					<?php echo base_url(); ?>assets/img/gallery/3.JFIF" class="gallery-foto" />
             
            </div>
            <div class="element-gallery">
              <img src="	
																						<?php echo base_url(); ?>assets/img/gallery/3.JFIF" class="gallery-foto" />
             
            </div>
            <div class="element-gallery">
              <img src="	
																							<?php echo base_url(); ?>assets/img/gallery/4.JFIF" class="gallery-foto" />
             
            </div>
          </div>
        </div>
      </div>
    </div>
</section>

 <!-- BANK -->
 <section>
    <div class="container reveal" id="gallery">
      <div class="col-lg-12 col-12 element-text">
        <img src="
						
																<?php echo base_url(); ?>assets/img/icon1.png" class="rounded-img-icon" />
      </div>
      <div class="col-lg-12 col-12 element-text">
     
      </div>
      <div class="col-lg-12 col-12 element-text element-margin">
        <div id="box" class="rounded">
        <p class="text">Tanpa mengurangi rasa hormat, bagi anda yang ingin memberikan tanda kasih untuk kami, dapat melalui:</p>
          <div class="row">
          <div class="col-lg-12 col-12 element-text">
          <img src="
						
            <?php echo base_url(); ?>assets/img/bca.png" style="width: 71px;" />
            <div class="col-lg-12 col-12 element-text">
                <a>*********** a.n aldo </a>
              </div>
      </div>
          </div>
        </div>
      </div>
    </div>
</section>

 <!-- BUKU TAMU -->
 <section>
      <div class="container reveal" id="chat">
        <div class="col-lg-12 col-12 element-text">
          <img src="
						
													<?php echo base_url(); ?>assets/img/icon1.png" class="rounded-img-icon" />
        </div>
        <div class="col-lg-12 col-12 element-text">
          <a>BUKU TAMU & RSVP</a>
        </div>
       
         
        <div class="col-lg-12 col-12 element-text element-margin">
          <div id="box" class="rounded">
          <div class="col-lg-12 col-12 element-text">
          <a>BUKU TAMU</a>
        </div>
          <div class="col-lg-12 col-12 element-text element-margin">
          <!-- <div class="pull-right"><a href="#" class="btn btn-primary_rsv btn-sm" data-toggle="modal" data-target="#ModalaAdd"><span class="fa fa-plus"></span>TAMBAH UCAPAN</a></div>  -->
          <button type="button" class="btn btn-primary_rsv" data-bs-toggle="modal" data-bs-target="#ModalaAdd">
  TAMBAH KOMENTAR
</button>

            </div>
       
            <div class="row">
		<div id="reload">
		<table class="table" id="mydata">
			<thead>
				<tr>
					<th> </th>       
					<th></th>
					<!-- <th style="display: none;">Aksi</th>
					<th style="display: none;"></th> -->
				</tr>
			</thead>
			<tbody id="show_data">
				
			</tbody>
		</table>
		</div>
	</div>
</div>
        </div>
      </div>
    </section>
<!-- Modal -->
<div class="modal fade" id="ModalaAdd" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <!-- <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button> -->
        <h3 class="modal-title" id="myModalLabel">Tambah Komentar</h3>
      </div>

      <form class="form-horizontal">
      <div class="modal-body">
      <div class="form-group">
                        <label class="control-label col-xs-3" >Nama</label>
                        <div class="col-xs-9">
                            <input name="vnamatamu" onsubmit="return validateForm()" id="nama_tamu" class="form-control" type="text" placeholder="Nama" required/>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-xs-3" >Komentar</label>
                        <div class="col-xs-9">
                    
                            <textarea rows="4" cols="50" minlength="2" name="vkomentartamu" id="komentar_tamu" type="text" class="form-control"  placeholder="Komentar" required></textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-xs-3" >Jumlah Hadir</label>
                        <div class="col-xs-9">
                            <input name="vjumlahtamu" minlength="1" id="jumlah_tamu" class="form-control" type="number" placeholder="Jumlah Hadir"  required/>
                        </div>
                    </div>

                
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary_rsv" data-bs-dismiss="modal">Close</button>
        <button type="button" id="btn_simpan" class="btn btn-primary_rsv" data-bs-dismiss="modal" type="submit">Save</button>
        <!-- <button type="button" id="btn_simpan" class="btn btn-primary">Save changes</button> -->
      </div>
      </form>
    </div>
  </div>
</div>
<!-- Modal -->
    


 <!-- FOOTER -->
 <section>
    <div class="container reveal" id="gallery">
      <div class="col-lg-12 col-12 element-text">
        <img src="
						
																<?php echo base_url(); ?>assets/img/icon1.png" class="rounded-img-icon" />
      </div>
      <div class="col-lg-12 col-12 element-text">
     
      </div>
      <div class="col-lg-12 col-12 element-text element-margin">
        <div id="box" class="rounded">
        <p class="text">Created By Rosi</p>
          <div class="row">

          </div>
        </div>
      </div>
    </div>
</section>
</div>
</div>


<!-- ICON LEFT AND RIGHT START -->
<div class="row">
  <div class="col-6">
    <img src="
			
			<?php echo base_url(); ?>assets/img/3.png" id="leftImage" />
  </div>
  <div class="col-6">
    <img src="
				
				<?php echo base_url(); ?>assets/img/4.png" id="rightImage" />
  </div>
</div>
<!-- ICON LEFT AND RIGHT END -->
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<script type="text/javascript">
	$(document).ready(function(){
		tampil_data_barang();	//pemanggilan fungsi tampil barang.
		
		// $('#mydata').dataTable();
    $('#mydata').dataTable({searching: false, paging: false, info: false});
		//fungsi tampil barang
		function tampil_data_barang(){
		    $.ajax({
		        type  : 'GET',
		        url   : '<?php echo base_url()?>/home/data_barang',
		        async : true,
		        dataType : 'json',
		        success : function(data){
		            var html = '';
		            var i;
		            for(i=0; i<data.length; i++){
		                html += '<tr>'+
		                  		// '<td></td>'+    <img src="<?php echo base_url(); ?>assets/img/1.png" id="leftImage" />
                          '<td style="text-align: left;width: 0%;""><img src="https://www.w3schools.com/howto/img_avatar.png" style="width:25px;border-radius: 64%;"" /></td>'+
		                        '<td style="text-align: left;"><b>'+data[i].nama_tamu+' </b><p style="text-align: left;">'+data[i].komentar_tamu+'</p></td>'+
		                        // '<p style="text-align: left;">'+data[i].barang_nama+'</p>'+
		                        '</tr>';
		            }
		            $('#show_data').html(html);
		        }

		    });
		}
		//Simpan Barang
		$('#btn_simpan').on('click',function(){
            var vnamatamu=$('#nama_tamu').val();
            var vkomentartamu=$('#komentar_tamu').val();
            var vjumlahtamu=$('#jumlah_tamu').val();
            $.ajax({
                type : "POST",
                url  : "<?php echo base_url('/home/simpan_barang')?>",
                dataType : "JSON",
                data : {vnamatamu:vnamatamu , vkomentartamu:vkomentartamu, vjumlahtamu:vjumlahtamu},
                success: function(data){
                    $('[name="vnamatamu"]').val("");
                    $('[name="vkomentartamu"]').val("");
                    $('[name="vjumlahtamu"]').val("");
                    $('#ModalaAdd').modal('hide');
                    tampil_data_barang();
                }
            });
            return false;
        });

 

	});

</script>
