
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/wdp.min.js' id='weddingpress-wdp-js'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/dce-editor-copy.js' id='dce-clipboard-js-js'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/script.min.js' id='landingpress-js'></script>
<script>
function getDomain($url){
    $pieces = parse_url($url);
    $domain = isset($pieces['host']) ? $pieces['host'] : '';
    if(preg_match('/(?P<domain>[a-z0-9][a-z0-9\-]{1,63}\.[a-z\.]{2,6})$/i', $domain, $regs)){
        return $regs['domain'];
    }
    return FALSE;
}

</script>

</body>
</html>
