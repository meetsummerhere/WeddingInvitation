<!DOCTYPE html>
<html lang="id-ID">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1.0">
	<title>𝓐𝓵𝓭𝓸 & 𝓐𝓷𝓰𝓮𝓵𝓲𝓷𝓪</title>
	<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery.min.js' id='jquery-core-js'></script>
	<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery-migrate.min.js' id='jquery-migrate-js'></script>
	<link rel="stylesheet" href='<?php echo base_url(); ?>assets/css/dashboard.css'>
</head>
<style>

</style>
<body oncontextmenu="return false" onkeydown="return false;" onmousedown="return false;">